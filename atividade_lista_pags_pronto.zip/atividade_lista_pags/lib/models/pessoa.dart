class Pessoa {
  String nome;
  String email;
  String telefone;
  bool estadoCivil;

  Pessoa(
      {required this.nome,
      required this.email,
      required this.estadoCivil,
      required this.telefone});
}
