import 'package:flutter/cupertino.dart';

class EditCadastro extends StatelessWidget {
  const EditCadastro({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
